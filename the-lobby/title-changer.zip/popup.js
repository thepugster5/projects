function setTitle(newTitle) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (title) => {
        document.title = title;
      },
      args: [newTitle],
    });
  });
}

function setFavicon(url) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (faviconUrl) => {
        let link = document.querySelector("link[rel*='icon']") || document.createElement('link');
        link.rel = 'icon';
        link.href = faviconUrl;
        document.head.appendChild(link);
      },
      args: [url],
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('changeTitleBtn').addEventListener('click', () => {
    const newTitle = document.getElementById('titleInput').value;
    if (newTitle) setTitle(newTitle);
  });

  document.querySelectorAll('.favicon-button').forEach((img) => {
    img.addEventListener('click', () => {
      const url = img.getAttribute('data-favicon');
      if (url) setFavicon(url);
    });
  });

  document.getElementById('customFaviconBtn').addEventListener('click', () => {
    const customUrl = document.getElementById('customFavicon').value;
    if (customUrl) setFavicon(customUrl);
  });
});